package com.test;

public class BClass {
    public void print(){
        new CClass().print();
        System.out.println(this.getClass().getName());
    }
}