package com.test;

public class CClass {
    public void print(){
        System.out.println(this.getClass().getName());
    }
}
